import express from "express";

const app = express();
app.use(express.json({ limit: "1mb" }));

const keys = [
  process.env.OPENAI_API_KEY_1,
  process.env.OPENAI_API_KEY_2,
  process.env.OPENAI_API_KEY_3,
  process.env.OPENAI_API_KEY_4,
  process.env.OPENAI_API_KEY_5
].filter(Boolean);

const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const port = process.env.PORT || 3000;

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "MAYA AI", configuredKeys: keys.length, model });
});

app.post("/chat", async (req, res) => {
  const message = String(req.body?.message || "").trim();
  if (!message) return res.status(400).json({ error: "message is required" });
  if (message.length > 12000) return res.status(413).json({ error: "message too long" });
  if (!keys.length) return res.status(503).json({ error: "No API key configured on server" });

  const instructions = "তোমার নাম MAYA। তুমি বন্ধুসুলভ বাংলা AI সহকারী। ব্যবহারকারীর ভাষা অনুযায়ী উত্তর দাও। তুমি ফোনে কাজ করার নির্দেশনা দিতে পারো, কিন্তু নিজে থেকে কোনো বাহ্যিক কাজ সম্পন্ন হয়েছে বলে দাবি করবে না। মেসেজ পাঠানো বা কিছু প্রকাশের আগে ব্যবহারকারীর নিশ্চিতকরণ দরকার।";
  let lastStatus = 502;

  // Try configured keys in order. Never return or log the secret.
  for (const key of keys) {
    try {
      const r = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${key}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          instructions,
          input: message,
          max_output_tokens: 700
        })
      });
      const data = await r.json().catch(() => ({}));
      if (r.ok) {
        const output = (data.output || [])
          .flatMap(item => item.content || [])
          .filter(part => part.type === "output_text")
          .map(part => part.text)
          .join("\n");
        return res.json({ reply: output || "আমি উত্তর তৈরি করতে পারিনি।" });
      }
      lastStatus = r.status;
      // Try next key only for authentication, quota, or rate-limit failures.
      if (![401, 403, 429].includes(r.status)) {
        return res.status(r.status).json({ error: "AI provider request failed", status: r.status });
      }
    } catch {
      return res.status(502).json({ error: "AI provider connection failed" });
    }
  }
  return res.status(lastStatus).json({
    error: "No configured API key could complete this request. Check key validity, project access, quota and billing."
  });
});

app.listen(port, () => console.log(`MAYA backend listening on ${port}`));
