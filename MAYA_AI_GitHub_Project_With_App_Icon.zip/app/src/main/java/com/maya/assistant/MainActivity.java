package com.maya.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 10;
    private static final int REQ_AUDIO = 11;
    private EditText commandInput;
    private TextView statusText;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        commandInput = findViewById(R.id.commandInput);
        statusText = findViewById(R.id.statusText);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("bn", "BD"));
        });

        findViewById(R.id.sendBtn).setOnClickListener(v -> runCommand(commandInput.getText().toString()));
        findViewById(R.id.micBtn).setOnClickListener(v -> startListening());
        findViewById(R.id.musicBtn).setOnClickListener(v -> openUrl("https://music.youtube.com"));
        findViewById(R.id.studyBtn).setOnClickListener(v -> speak("চলো আজকে পড়াশোনা করি। কী শিখতে চাও?"));
        findViewById(R.id.journalBtn).setOnClickListener(v -> speak("তোমার ডায়েরিতে কী লিখব?"));
    }

    private void startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Maya-কে বলো...");
        try { startActivityForResult(i, REQ_SPEECH); }
        catch (Exception e) { sayStatus("এই ফোনে Speech Recognition পাওয়া যায়নি।"); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && !matches.isEmpty()) {
                commandInput.setText(matches.get(0));
                runCommand(matches.get(0));
            }
        }
    }

    private void runCommand(String raw) {
        String s = raw == null ? "" : raw.toLowerCase(Locale.ROOT).trim();
        if (s.isEmpty()) return;

        if (s.contains("youtube") || s.contains("ইউটিউব")) {
            String query = extractSearch(s);
            if (query.isEmpty()) openUrl("https://www.youtube.com");
            else openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(query));
            speak("ইউটিউব খুলছি।");
        } else if (s.contains("whatsapp") || s.contains("হোয়াটসঅ্যাপ")) {
            openAppOrStore("com.whatsapp");
            speak("হোয়াটসঅ্যাপ খুলছি।");
        } else if (s.contains("telegram") || s.contains("টেলিগ্রাম")) {
            openAppOrStore("org.telegram.messenger");
            speak("টেলিগ্রাম খুলছি।");
        } else if (s.contains("tiktok") || s.contains("টিকটক")) {
            openUrl("https://www.tiktok.com");
            speak("টিকটক খুলছি।");
        } else if (s.contains("গান") || s.contains("song")) {
            openUrl("https://music.youtube.com");
            speak("গান চালানোর অ্যাপ খুলছি।");
        } else {
            speak("তোমার কথা শুনেছি। AI chat যুক্ত করতে API সেটআপ করতে হবে।");
            sayStatus("Command: " + raw + " — AI API এখনো সংযুক্ত নয়।");
        }
    }

    private String extractSearch(String s) {
        String[] keys = {"search ", "সার্চ ", "খুঁজে ", "গান "};
        for (String k : keys) {
            int p = s.indexOf(k);
            if (p >= 0 && p + k.length() < s.length()) return s.substring(p + k.length()).trim();
        }
        return "";
    }

    private void openAppOrStore(String packageName) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch != null) startActivity(launch);
        else openUrl("https://play.google.com/store/apps/details?id=" + packageName);
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { sayStatus("লিংকটি খোলা যায়নি।"); }
    }

    private void speak(String message) {
        sayStatus(message);
        if (tts != null) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "maya_reply");
    }

    private void sayStatus(String message) { statusText.setText(message); }

    @Override public void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
